# TOOLS

Open cash drawer API \ Открытие денежнего ящика

**URL** : `print/open_cash_drawer`

**Method** : `GET`

**Auth required** : NO

## Response

```json
{
  "data":null,
  "error": {
    "code":[code of error],
    "message":[error message],
    "data":[extra data for error]
    },
  "is_success": [is success response] 
}
```
